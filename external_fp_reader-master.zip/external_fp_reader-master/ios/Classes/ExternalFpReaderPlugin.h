#import <Flutter/Flutter.h>

@interface ExternalFpReaderPlugin : NSObject<FlutterPlugin>
@end
