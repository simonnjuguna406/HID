package br.com.pontocare.externalfpreader.external_fp_reader_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
